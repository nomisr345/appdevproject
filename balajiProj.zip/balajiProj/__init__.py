from flask import Flask, render_template, request, redirect, url_for
from Forms import CreateAccountForm, CreateCustomerForm, LoginForm, CreateStaffForm
import shelve, Account, Customer, Staff

app = Flask(__name__)

@app.route('/')
def home():
    return render_template('home.html')

@app.route('/contactUs')
def contact_us():
    return render_template('contactUs.html')

@app.route('/customer')
def customer():
    return render_template('home.html')

@app.route('/staff')
def staff():
    return render_template('homeStaff.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    login_form = LoginForm(request.form)
    if request.method == 'POST' and login_form.validate():
        print('SDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDD')
        return render_template('home.html')
    print('hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh')
    return render_template('Login.html', form=login_form)

@app.route('/createAccount', methods=['GET', 'POST'])
def create_account():
    create_account_form = CreateAccountForm(request.form)
    if request.method == 'POST' and create_account_form.validate():
        accounts_dict = {}
        db = shelve.open('account.db', 'c')

        try:
            accounts_dict = db['Accounts']
        except:
            print("Error in retrieving Accounts from account.db.")

        account = Account.Account(create_account_form.first_name.data, create_account_form.last_name.data, create_account_form.email.data, create_account_form.date_of_birth.data, create_account_form.gender.data, create_account_form.membership.data, create_account_form.remarks.data)
        accounts_dict[account.get_account_id()] = account
        db['Accounts'] = accounts_dict

        db.close()

        return redirect(url_for('retrieve_account'))
    return render_template('createAccount.html', form=create_account_form)

@app.route('/createStaff', methods=['GET', 'POST'])
def create_staff():
    create_staff_form = CreateStaffForm(request.form)
    if request.method == 'POST' and create_staff_form.validate():
        staffs_dict = {}
        db = shelve.open('staff.db', 'c')

        try:
            staffs_dict = db['Staffs']
        except:
            print("Error in retrieving Users from user.db.")

        staff = Staff.Staff(create_staff_form.first_name.data, create_staff_form.last_name.data, create_staff_form.department.data, create_staff_form.designation.data, create_staff_form.email.data, create_staff_form.password.data)
        staffs_dict[staff.get_staff_id()] = staff
        db['Staffs'] = staffs_dict

        db.close()

        return redirect(url_for('retrieve_staffs'))
    return render_template('createStaff.html', form=create_staff_form)

@app.route('/createCustomer', methods=['GET', 'POST'])
def create_customer():
    create_customer_form = CreateCustomerForm(request.form)
    if request.method == 'POST' and create_customer_form.validate():
        customers_dict = {}
        db = shelve.open('customer.db', 'c')

        try:
            customers_dict = db['Customers']
        except:
            print("Error in retrieving Customers from customer.db.")

        customer = Customer.Customer(create_customer_form.first_name.data, create_customer_form.last_name.data,
                                     create_customer_form.email.data,create_customer_form.date_of_birth.data,create_customer_form.gender.data, create_customer_form.membership.data,
                                     create_customer_form.remarks.data, create_customer_form.email.data,
                                     create_customer_form.date_joined.data, create_customer_form.address.data)
##        customers_dict[customer.get_customer_id()] = customer
        customers_dict[customer.get_account_id()] = customer
        db['Customers'] = customers_dict

        db.close()

        return redirect(url_for('retrieve_customers'))
    return render_template('createCustomer.html', form=create_customer_form)

@app.route('/retrieveAccount')
def retrieve_account():
    account_dict = {}
    db = shelve.open('account.db', 'r')
    account_dict = db['Accounts']
    db.close()

    accounts_list = []
    for key in account_dict:
        account = account_dict.get(key)
        accounts_list.append(account)

    return render_template('retrieveAccount.html', count=len(accounts_list), users_list=accounts_list)

@app.route('/retrieveStaffs')
def retrieve_staffs():
    print('nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn')
    staffs_dict = {}
    db = shelve.open('staff.db', 'r')
    staffs_dict = db['Staffs']
    db.close()

    staffs_list = []
    for key in staffs_dict:
        staff = staffs_dict.get(key)
        staffs_list.append(staff)
    return render_template('retrieveStaffs.html', count=len(staffs_list), staffs_list=staffs_list)

@app.route('/retrieveCustomers')
def retrieve_customers():
    customers_dict = {}
    db = shelve.open('customer.db', 'r')
    customers_dict = db['Customers']
    db.close()

    customers_list = []
    for key in customers_dict:
        customer = customers_dict.get(key)
        customers_list.append(customer)

    return render_template('retrieveCustomers.html', count=len(customers_list), customers_list=customers_list)

@app.route('/updateAccount/<int:id>/', methods=['GET', 'POST'])
def update_account(id):
    update_account_form = CreateAccountForm(request.form)
    if request.method == 'POST' and update_account_form.validate():
        accounts_dict = {}
        db = shelve.open('account.db', 'w')
        accounts_dict = db['Accounts']

        account = accounts_dict.get(id)
        account.set_first_name(update_account_form.first_name.data)
        account.set_last_name(update_account_form.last_name.data)
        account.set_email(update_account_form.email.data)
        account.set_date_of_birth(update_account_form.date_of_birth.data)
        account.set_gender(update_account_form.gender.data)
        account.set_membership(update_account_form.membership.data)
        account.set_remarks(update_account_form.remarks.data)

        db['Accounts'] = accounts_dict
        db.close()

        return redirect(url_for('retrieve_account'))
    else:
        accounts_dict = {}
        db = shelve.open('account.db', 'r')
        accounts_dict = db['Accounts']
        db.close()

        account = accounts_dict.get(id)
        update_account_form.first_name.data = account.get_first_name()
        update_account_form.last_name.data = account.get_last_name()
        update_account_form.email.data = account.get_email()
        update_account_form.date_of_birth.data = account.get_date_of_birth()
        update_account_form.gender.data = account.get_gender()
        update_account_form.membership.data = account.get_membership()
        update_account_form.remarks.data = account.get_remarks()

        return render_template('updateAccount.html', form=update_account_form)

@app.route('/updateCustomer/<int:id>/', methods=['GET', 'POST'])
def update_customer(id):
    update_customer_form = CreateCustomerForm(request.form)
    if request.method == 'POST' and update_customer_form.validate():
        customers_dict = {}
        db = shelve.open('customer.db', 'w')
        customers_dict = db['Customers']

        customer = customers_dict.get(id)
        customer.set_first_name(update_customer_form.first_name.data)
        customer.set_last_name(update_customer_form.last_name.data)
        customer.set_email(update_customer_form.email.data)
        customer.set_date_of_birth(update_customer_form.date_of_birth.data)
        customer.set_gender(update_customer_form.gender.data)
        customer.set_email(update_customer_form.email.data)
        customer.set_date_joined(update_customer_form.date_joined.data)
        customer.set_address(update_customer_form.address.data)
        customer.set_membership(update_customer_form.membership.data)
        customer.set_remarks(update_customer_form.remarks.data)

        db['Customers'] = customers_dict
        db.close()

        return redirect(url_for('retrieve_customers'))
    else:
        customers_dict = {}
        db = shelve.open('customer.db', 'r')
        customers_dict = db['Customers']
        db.close()

        customer = customers_dict.get(id)
        update_customer_form.first_name.data = customer.get_first_name()
        update_customer_form.last_name.data = customer.get_last_name()
        update_customer_form.email.data = customer.get_email()
        update_customer_form.date_of_birth.data = customer.get_date_of_birth()
        update_customer_form.gender.data = customer.get_gender()
        update_customer_form.email.data = customer.get_email()
        update_customer_form.date_joined.data = customer.get_date_joined()
        update_customer_form.address.data = customer.get_address()
        update_customer_form.membership.data = customer.get_membership()
        update_customer_form.remarks.data = customer.get_remarks()

        return render_template('updateCustomer.html', form=update_customer_form)

@app.route('/deleteAccount/<int:id>', methods=['POST'])
def delete_account(id):
    accounts_dict = {}
    db = shelve.open('account.db', 'w')
    accounts_dict = db['Accounts']

    accounts_dict.pop(id)

    db['Accounts'] = accounts_dict
    db.close()

    return redirect(url_for('retrieve_account'))

@app.route('/deleteCustomer/<int:id>', methods=['POST'])
def delete_customer(id):
    customers_dict = {}
    db = shelve.open('customer.db', 'w')
    customers_dict = db['Customers']
    customers_dict.pop(id)

    db['Customers'] = customers_dict
    db.close()

    return redirect(url_for('retrieve_customers'))

if __name__ == '__main__':
    app.run()

