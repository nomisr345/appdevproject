from flask import Flask, render_template, request, redirect, url_for
from Forms import CreateProductForm
import shelve, Product

app = Flask(__name__)

@app.route('/')
def home():
    return render_template('home.html')

@app.route('/customerHome')
def customer_home():
    return render_template('home.html')

@app.route('/staffHome')
def staff_home():
    return render_template('staffhome.html')

@app.route('/product')
def product():
    products_dict = {}
    db = shelve.open('product.db', 'r')
    products_dict = db['Products']
    db.close()

    products_list = []
    for key in products_dict:
        product = products_dict.get(key)
        products_list.append(product)

    return render_template('product.html', count=len(products_list), products_list=products_list)

@app.route('/createProduct', methods=['GET', 'POST'])
def create_product():
    create_product_form = CreateProductForm(request.form)
    if request.method == 'POST' and create_product_form.validate():
        products_dict = {}
        db = shelve.open('product.db', 'c')

        try:
            products_dict = db['Products']
        except:
            print("Error in retrieving Products from product.db.")

        product = Product.Product(create_product_form.product_name.data, create_product_form.product_price.data, create_product_form.product_release.data, create_product_form.product_desc.data)
        products_dict[product.get_product_id()] = product
        db['Products'] = products_dict

        db.close()

        return redirect(url_for('retrieve_products'))
    return render_template('createProduct.html', form=create_product_form)

@app.route('/retrieveProducts')
def retrieve_products():
    products_dict = {}
    db = shelve.open('product.db', 'r')
    products_dict = db['Products']
    db.close()

    products_list = []
    for key in products_dict:
        product = products_dict.get(key)
        products_list.append(product)

    return render_template('retrieveProducts.html', count=len(products_list), products_list=products_list)

@app.route('/updateProduct/<int:id>/', methods=['GET', 'POST'])
def update_product(id):
    update_product_form = CreateProductForm(request.form)
    if request.method == 'POST' and update_product_form.validate():
        products_dict = {}
        db = shelve.open('product.db', 'w')
        products_dict = db['Products']

        product = products_dict.get(id)
        product.set_product_name(update_product_form.product_name.data)
        product.set_product_price(update_product_form.product_price.data)
        product.set_product_release(update_product_form.product_release.data)
        product.set_product_desc(update_product_form.product_desc.data)

        db['Products'] = products_dict
        db.close()

        return redirect(url_for('retrieve_products'))
    else:
        products_dict = {}
        db = shelve.open('product.db', 'r')
        products_dict = db['Products']
        db.close()

        product = products_dict.get(id)
        update_product_form.product_name.data = product.get_product_name()
        update_product_form.product_price.data = product.get_product_price()
        update_product_form.product_release.data = product.get_product_release()
        update_product_form.product_desc.data = product.get_product_desc()

        return render_template('updateProduct.html', form=update_product_form)

@app.route('/deleteProduct/<int:id>', methods=['POST'])
def delete_product(id):
    products_dict = {}
    db = shelve.open('product.db', 'w')
    products_dict = db['Products']

    products_dict.pop(id)

    db['Products'] = products_dict
    db.close()

    return redirect(url_for('retrieve_products'))

@app.route('/login')
def login():
    return render_template('login.html')

@app.route('/charts')
def charts():
    return render_template('charts.html')

if __name__ == '__main__':
    app.run()
