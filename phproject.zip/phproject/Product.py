class Product:
    count_id = 0

    def __init__(self, product_name, product_price, product_release, product_desc):
        Product.count_id += 1
        self.__product_id = Product.count_id
        self.__product_name = product_name
        self.__product_price = product_price
        self.__product_release = product_release
        self.__product_desc = product_desc

    # accessor methods
    def get_product_id(self):
        return self.__product_id

    def get_product_name(self):
        return self.__product_name

    def get_product_price(self):
        return self.__product_price

    def get_product_release(self):
        return self.__product_release

    def get_product_desc(self):
        return self.__product_desc

    # mutator methods
    def set_product_id(self, user_id):
        self.__product_id = product_id

    def set_product_name(self, product_name):
        self.__product_name = product_name

    def set_product_price(self, product_price):
        self.__product_price = product_price

    def set_product_release(self, product_release):
        self.__product_release = product_release

    def set_product_desc(self, product_desc):
        self.__product_desc = product_desc
