from wtforms import Form, StringField, RadioField, SelectField, TextAreaField, validators
from wtforms.fields import EmailField, DateField
from datetime import date

class CreateProductForm(Form):
    product_name = StringField('Product Name', [validators.Length(min=1, max=100), validators.DataRequired()])
    product_price = StringField('Price', [validators.Length(min=1, max=10), validators.DataRequired()])
    product_release = DateField('Date Released', [validators.DataRequired()])
    product_desc = TextAreaField('Description', [validators.Optional()])
