class Reward:
    count_id = 0

    # initializer method
    #def __init__(self, reward_name, points_required, points_expiry, reward_type, description,file):
    def __init__(self, reward_name, points_required, points_expiry, reward_type, description,reward_pic):
        Reward.count_id += 1
        self.__reward_id = Reward.count_id
        self.__reward_name = reward_name
        self.__points_required = points_required
        self.__points_expiry = points_expiry
        self.__reward_type = reward_type
        self.__description = description
        self.__reward_pic = reward_pic
        self.__claim_flag = 0

      #  self.__file = file

    # accessor methods
    def get_reward_id(self):
        return self.__reward_id

    def get_reward_name(self):
        return self.__reward_name

    def get_points_required(self):
        return self.__points_required

    def get_points_expiry(self):
        return self.__points_expiry

    def get_reward_type(self):
        return self.__reward_type

    def get_description(self):
        return self.__description

    def get_reward_pic(self):
        return self.__reward_pic  

    def get_claim_flag(self):
        return self.__claim_flag



    #def get_file(self):
    #    return self.__file

    # mutator methods
    def set_reward_id(self, reward_id):
        self.__reward_id = reward_id

    def set_reward_name(self, reward_name):
        self.__reward_name = reward_name

    def set_points_required(self, points_required):
        self.__points_required = points_required

    def set_points_expiry(self, points_expiry):
        self.__points_expiry = points_expiry

    def set_reward_type(self, reward_type):
        self.__reward_type = reward_type

    def set_description(self, description):
        self.__description = description

    def set_reward_pic(self, reward_pic):
        self.__reward_pic = reward_pic    

    def set_claim_flag(self, claim_flag):
        self.__claim_flag = claim_flag



    #def set_file(self, file):
     #   self.__file = file
