A simple module for an e-commerce site
Make sure you have sqlalchemy installed
if not then run the following command in your terminal
  pip install -U Flask-SQLAlchemy

to run the application set enviornment variables in your terminal as follows
  set FLASK_APP=application.py
  set FLASK_DEBUG=1
and then finally
  flask run
