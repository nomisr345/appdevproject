from flask import Flask, render_template, request, redirect, url_for
from Forms import CreateRewardForm
import shelve, Reward
from werkzeug.utils import secure_filename
import os
from wtforms.validators import NumberRange

app = Flask(__name__)

#static file path
@app.route("/static/<path:path>")
def static_dir(path):
    return send_from_directory("static", path)


@app.route('/')
def chome():
    return render_template('chome.html')

@app.route('/my_reward')
def my_reward():
    return render_template('my_reward.html')

@app.route('/claimReward')
def claim_reward():
    claim_reward_data = get_claim_reward_data()
    return render_template('claimReward.html', rewards=claim_reward_data)

def get_claim_reward_data():
    # code to retrieve rewards data from a database or other storage
    claim_reward_data = [
        {'name': 'Reward 1', 'points': 100},
        {'name': 'Reward 2', 'points': 200},
        {'name': 'Reward 3', 'points': 300},
    ]
    return claim_reward_data

@app.route('/contactUs')
def contact_us():
    return render_template('contactUs.html')

@app.route('/home')
def home():
    return render_template('shome.html')

@app.route('/createReward', methods=['GET', 'POST'])
def create_reward():
    create_reward_form = CreateRewardForm(request.form)
    if request.method == 'POST' and create_reward_form.validate():
        rewards_dict = {}
        db = shelve.open('reward.db', 'c')
        #file = CreateRewardForm.image.data
        #filename = secure_filename(file.filename)
        #file.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))
        f = request.files['reward_pic']
        f.save(app.root_path+'/static/images/'+f.filename)
        create_reward_form.reward_pic.data = f.filename  
        try:
            rewards_dict = db['Rewards']
        except:
            print("Error in retrieving Reward from reward.db.")

        reward = Reward.Reward(create_reward_form.reward_name.data, create_reward_form.points_required.data, create_reward_form.points_expiry.data, create_reward_form.reward_type.data, create_reward_form.description.data, create_reward_form.reward_pic.data)
        rewards_dict[reward.get_reward_id()] = reward

        db['Rewards'] = rewards_dict
        db.close()



        return redirect(url_for('retrieve_rewards'))
    return render_template('createReward.html', form=create_reward_form)


@app.route('/retrieveRewards')
def retrieve_rewards():
    rewards_dict = {}
    db = shelve.open('reward.db', 'r')
    rewards_dict = db['Rewards']
    db.close()

    rewards_list = []
    for key in rewards_dict:
        reward = rewards_dict.get(key)
        rewards_list.append(reward)

    return render_template('retrieveRewards.html', count=len(rewards_list), users_list=rewards_list)

@app.route('/updateReward/<int:id>/', methods=['GET', 'POST'])
def update_reward(id):
    update_reward_form = CreateRewardForm(request.form)
    if request.method == 'POST' and update_reward_form.validate():
        rewards_dict = {}
        db = shelve.open('reward.db', 'w')
        rewards_dict = db['Rewards']

        reward = rewards_dict.get(id)
        reward.set_reward_name(update_reward_form.reward_name.data)
        reward.set_points_required(update_reward_form.points_required.data)
        reward.set_points_expiry(update_reward_form.points_expiry.data)
        reward.set_reward_type(update_reward_form.reward_type.data)
        reward.set_description(update_reward_form.description.data)
        if request.files.get('reward_pic', None):
            f = request.files['reward_pic']
            f.save(app.root_path+'/static/images/'+f.filename)
            reward.set_reward_pic(f.filename)

        db['Rewards'] = rewards_dict
        db.close()

        return redirect(url_for('retrieve_rewards'))
    else:
        rewards_dict = {}
        db = shelve.open('reward.db', 'r')
        rewards_dict = db['Rewards']
        db.close()
        reward = rewards_dict.get(id)
        update_reward_form.reward_name.data = reward.get_reward_name()
        update_reward_form.points_required.data = reward.get_points_required()
        update_reward_form.points_expiry.data = reward.get_points_expiry()
        update_reward_form.reward_type.data = reward.get_reward_type()
        update_reward_form.description.data = reward.get_description()
        update_reward_form.reward_pic.data = reward.get_reward_pic()
        reward_image = reward.get_reward_pic()

        return render_template('updateReward.html', form=update_reward_form,reward_img=reward_image)

@app.route('/deleteReward/<int:id>', methods=['POST'])
def delete_reward(id):
    rewards_dict = {}
    db = shelve.open('reward.db', 'w')
    rewards_dict = db['Rewards']

    rewards_dict.pop(id)

    db['Rewards'] = rewards_dict
    db.close()

    return redirect(url_for('retrieve_rewards'))


if __name__ == '__main__':
    app.run(debug=True)
    #app.run(host='0.0.0.0', port=80,debug=True)
