import os
from Forms import CreateRewardForm
import uuid
from flask import Flask, session,render_template,request, Response, redirect, send_from_directory,url_for
from werkzeug.utils import secure_filename
from werkzeug.security import check_password_hash, generate_password_hash
from db import db_init, db
from models import  User, Product
from datetime import datetime
from flask_session import Session
from helpers import login_required
import shelve, Reward
from wtforms.validators import NumberRange

#app = Flask(__name__)
app=Flask(__name__,template_folder='templates')
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///items.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db_init(app)

# Configure session to use filesystem
app.config["SESSION_PERMANENT"] = False
app.config["SESSION_TYPE"] = "filesystem"
Session(app)

#static file path
@app.route("/static/<path:path>")
def static_dir(path):
    return send_from_directory("static", path)

@app.route('/')
def chome():
    return render_template('chome.html')

@app.route('/points')
def points():
    return render_template('points.html')

@app.route('/shome')
def shome():
    return render_template('shome.html')


@app.route('/cr')
def cr():
    claim_reward_form = CreateRewardForm(request.form)
    rewards_dict = {}
    db = shelve.open('reward.db')
    rewards_dict = db['Rewards']
    db.close()

    rewards_list = []
    for key in rewards_dict:
        reward = rewards_dict.get(key)
        rewards_list.append(reward)
    print(len(rewards_list))
    return render_template('cr.html', count=len(rewards_list), users_list=rewards_list)



#signup as merchant
@app.route("/signup", methods=["GET","POST"])
def signup():
	if request.method=="POST":
		session.clear()
		password = request.form.get("password")
		repassword = request.form.get("repassword")
		if(password!=repassword):
			return render_template("error.html", message="Passwords do not match!")

		#hash password
		pw_hash = generate_password_hash(password, method='pbkdf2:sha256', salt_length=8)
		
		fullname = request.form.get("fullname")
		username = request.form.get("username")
		#store in database
		new_user =User(fullname=fullname,username=username,password=pw_hash)
		try:
			db.session.add(new_user)
			db.session.commit()
		except:
			return render_template("error.html", message="Username already exists!")
		return render_template("login.html", msg="Account created!")
	return render_template("signup.html")

#login as merchant
@app.route("/login", methods=["GET", "POST"])
def login():
	if request.method=="POST":
		session.clear()
		username = request.form.get("username")
		password = request.form.get("password")
		result = User.query.filter_by(username=username).first()
		print(result)
		# Ensure username exists and password is correct
		if result == None or not check_password_hash(result.password, password):
			return render_template("error.html", message="Invalid username and/or password")
		# Remember which user has logged in
		session["username"] = result.username
		return redirect("/home")
	return render_template("login.html")

#logout
@app.route("/logout")
def logout():
	session.clear()
	return redirect("/login")

#view all products
@app.route("/view_rewards")
def view_rewards():
	rows = Product.query.all()
	return render_template("view_rewards.html", rows=rows)

#merchant home page to add new products and edit existing products
@app.route("/home", methods=["GET", "POST"], endpoint='home')
@login_required
def home():
	if request.method == "POST":
		image = request.files['image']
		filename = str(uuid.uuid1())+os.path.splitext(image.filename)[1]
		image.save(os.path.join("static/images", filename))
		category = request.form.get("category")
		name = request.form.get("pro_name")
		description = request.form.get("description")
		price_range = request.form.get("price_range")
		comments = request.form.get("comments")
		new_pro = Product(category=category,name=name,description=description,price_range=price_range,comments=comments, filename=filename, username=session['username'])
		db.session.add(new_pro)
		db.session.commit()
		db.session.delete(new_pro)
		rows = Product.query.filter_by(username=session['username'])
		return render_template("home.html", rows=rows, message="Product added")
	
	rows = Product.query.filter_by(username=session['username'])
	return render_template("home.html", rows=rows)

#when edit product option is selected this function is loaded
@app.route("/edit/<int:pro_id>", methods=["GET", "POST"], endpoint='edit')
@login_required
def edit(pro_id):
	#select only the editing product from db
	result = Product.query.filter_by(pro_id = pro_id).first()
	if request.method == "POST":
		#throw error when some merchant tries to edit product of other merchant
		if result.username != session['username']:
			return render_template("error.html", message="You are not authorized to edit this product")
		image = request.files['image']
		filename = str(uuid.uuid1())+os.path.splitext(image.filename)[1]
		image.save(os.path.join("static/images", filename))
		category= request.form.get("category")
		name = request.form.get("pro_name")
		description = request.form.get("description")
		price_range = request.form.get("price_range")
		comments = request.form.get("comments")
		result.category = category
		result.name = name
		result.description = description
		result.comments = comments
		result.price_range = price_range
		db.session.commit()
		rows = Product.query.filter_by(username=session['username'])
		return render_template("home.html", rows=rows, message="Product edited")
	return render_template("edit.html", result=result)

# Peer - Rewards Entry

@app.route('/createReward', methods=['GET', 'POST'])
def create_reward():
    create_reward_form = CreateRewardForm(request.form)
    if request.method == 'POST' and create_reward_form.validate():
        rewards_dict = {}
        db = shelve.open('reward.db')
         # file = CreateRewardForm.image.data
      #  filename = secure_filename(file.filename)
      #  file.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))
        f = request.files['reward_pic']
        f.save(app.root_path+'/static/images/'+f.filename)
        create_reward_form.reward_pic.data = f.filename


        try:
            rewards_dict = db['Rewards']
        except:
            print("Error in retrieving Reward from reward.db.")

        #reward = Reward.Reward(create_reward_form.reward_name.data, create_reward_form.points_required.data, create_reward_form.points_expiry.data, create_reward_form.reward_type.data, create_reward_form.description.data,0)
        reward = Reward.Reward(create_reward_form.reward_name.data, create_reward_form.points_required.data, create_reward_form.points_expiry.data, create_reward_form.reward_type.data, create_reward_form.description.data, create_reward_form.reward_pic.data)
        rewards_dict[reward.get_reward_id()] = reward
        print("reward writen")
        db['Rewards'] = rewards_dict
        db.close()

        return redirect(url_for('retrieve_rewards'))
    return render_template('createReward.html', form=create_reward_form)

@app.route('/retrieveRewards')
def retrieve_rewards():
    rewards_dict = {}
    db = shelve.open('reward.db')
    rewards_dict = db['Rewards']
    db.close()

    rewards_list = []
    for key in rewards_dict:
        reward = rewards_dict.get(key)
        rewards_list.append(reward)
    print(len(rewards_list))
    return render_template('retrieveRewards.html', count=len(rewards_list), users_list=rewards_list)

# Peer - update rewards
@app.route('/updateReward/<int:id>/', methods=['GET', 'POST'])
def update_reward(id):
    update_reward_form = CreateRewardForm(request.form)
    if request.method == 'POST' and update_reward_form.validate():
        rewards_dict = {}
        db = shelve.open('reward.db', 'w')
        rewards_dict = db['Rewards']

        reward = rewards_dict.get(id)
        reward.set_reward_name(update_reward_form.reward_name.data)
        reward.set_points_required(update_reward_form.points_required.data)
        reward.set_points_expiry(update_reward_form.points_expiry.data)
        reward.set_reward_type(update_reward_form.reward_type.data)
        reward.set_description(update_reward_form.description.data)
        if request.files.get('reward_pic', None):
            f = request.files['reward_pic']
            f.save(app.root_path+'/static/images/'+f.filename)
            reward.set_reward_pic(f.filename)


        db['Rewards'] = rewards_dict
        db.close()

        return redirect(url_for('retrieve_rewards'))
    else:
        rewards_dict = {}
        db = shelve.open('reward.db', 'r')
        rewards_dict = db['Rewards']
        db.close()

        reward = rewards_dict.get(id)
        update_reward_form.reward_name.data = reward.get_reward_name()
        update_reward_form.points_required.data = reward.get_points_required()
        update_reward_form.points_expiry.data = reward.get_points_expiry()
        update_reward_form.reward_type.data = reward.get_reward_type()
        update_reward_form.description.data = reward.get_description()
        update_reward_form.reward_pic.data = reward.get_reward_pic()
        reward_image = reward.get_reward_pic()

        return render_template('updateReward.html', form=update_reward_form,reward_img=reward_image)
        #return render_template('updateReward.html', form=update_reward_form)

# Peer - delete

@app.route('/deleteReward/<int:id>', methods=['POST'])
def delete_reward(id):
    rewards_dict = {}
    db = shelve.open('reward.db', 'w')
    rewards_dict = db['Rewards']
    rewards_dict.pop(id)
    db['Rewards'] = rewards_dict
    db.close()

    return redirect(url_for('retrieve_rewards'))
# Peer - claim rewards
@app.route('/claimReward/<int:id>/', methods=['GET', 'POST'])
def claim_reward(id):
    claim_reward_form = CreateRewardForm(request.form)
    rewards_dict = {}
    db = shelve.open('reward.db', 'w')
    rewards_dict = db['Rewards']

    reward = rewards_dict.get(id)
    # reward.set_reward_name(claim_reward_form.reward_name.data)
    # reward.set_points_required(claim_reward_form.points_required.data)
    # reward.set_points_expiry(claim_reward_form.points_expiry.data)
    # reward.set_reward_type(claim_reward_form.reward_type.data)
    # reward.set_description(claim_reward_form.description.data)
    reward.set_claim_flag(1)
    print("claim_flag")
    print(reward.get_claim_flag())

    db['Rewards'] = rewards_dict
    db.close()

    return redirect(url_for('cr'))
    if request.method == 'POST' and claim_reward_form.validate():
        rewards_dict = {}
        db = shelve.open('reward.db', 'w')
        rewards_dict = db['Rewards']

        reward = rewards_dict.get(id)
        reward.set_reward_name(claim_reward_form.reward_name.data)
        reward.set_points_required(claim_reward_form.points_required.data)
        reward.set_points_expiry(claim_reward_form.points_expiry.data)
        reward.set_reward_type(claim_reward_form.reward_type.data)
        reward.set_description(claim_reward_form.description.data)
        reward.set_claim_flag(1)
        print("claim_flag")
        print(reward.get_claim_flag())

        db['Rewards'] = rewards_dict
        db.close()

        return redirect(url_for('cr'))
    else:
        rewards_dict = {}
        db = shelve.open('reward.db', 'r')
        rewards_dict = db['Rewards']
        db.close()

        reward = rewards_dict.get(id)
        claim_reward_form.reward_name.data = reward.get_reward_name()
        claim_reward_form.points_required.data = reward.get_points_required()
        claim_reward_form.points_expiry.data = reward.get_points_expiry()
        claim_reward_form.reward_type.data = reward.get_reward_type()
        claim_reward_form.description.data = reward.get_description()

        return render_template('claimReward.html', form=claim_reward_form)

if __name__ == '__main__':
    app.run(debug=True)
    #app.run(host='0.0.0.0', port=80,debug=True)
